# Wandering Heroes of Ogre Gate Foundry Notes

- Use `C:\Users\drago\Downloads\Wandering_Heroes_of_Ogre_Gate.pdf` as the rules authority for system behavior.
- Use `C:\Users\drago\Downloads\Ogre_Gate_Character_SheetForm_Fillable.pdf` as the visual authority for character, NPC tracker, and quick-reference sheet structure.
- Prefer implementing rules as sheet-visible calculations and warnings first, then hard-block actions only where the book is explicit.
- The first implementation target is a Foundry VTT v13 game system, not a module.
