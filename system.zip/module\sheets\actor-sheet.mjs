import { OGRE_GATE } from "../config.mjs";
import { prepareCharacterCreation } from "../rules/character-creation.mjs";

const { ActorSheetV2 } = foundry.applications.sheets;
const { HandlebarsApplicationMixin } = foundry.applications.api;

function getInputValue(input) {
  if (input.type === "checkbox") return input.checked;
  if (input.type === "number") return Number(input.value || 0);
  return input.value;
}

function escapeHtml(value = "") {
  const div = document.createElement("div");
  div.textContent = String(value ?? "");
  return div.innerHTML;
}

const ACTOR_HELP = {
  rollTn: "Target number for skill, defense, and attack rolls. A kept die equal to or above this number succeeds.",
  expertise: "When checked, defense rolls with a filled Expertise entry gain +1d10 and show the expertise name in chat. Skill Expertise is selected on each skill row.",
  pendingDamageBonus: "Damage bonus dice from attack total successes. Use the button on an attack chat card to fill this, or enter it manually. The next weapon damage roll consumes it.",
  preparedStrike: "Ready one attack against a designated zone and trigger. The system tracks whether it is armed and posts the reminder to chat.",
  charge: "Checks the declared straight-line movement for mounted charge or charge on foot and reminds you about mounted bow penalties.",
  drain: "Temporary drains reduce skill ranks, defense ratings, or effective Qi. Temporary drain usually recovers one point per day unless a rule says otherwise.",
  healing: "Heal a manual amount, apply natural healing, or roll Medicine/Meditation to stabilize a dying character.",
  affliction: "Medicine treatment for poisons and diseases: success stabilizes, total success cures, and failure resumes or continues the effect. Roll once per listed cadence.",
  health: "Current Health / Max Health. Damage lowers current Health. Below half Health the actor is Bloodied; at 0 Health the actor is automatically Dying.",
  dyingRounds: "Track rounds spent Dying. The limit shown is based on current Hardiness.",
  qiRank: "Qi rank drives Health, Qi resource maximums, and many martial requirements.",
  imbalance: "Track current imbalance against the maximum. Imbalance Rating equals the highest current Martial Discipline rank.",
  karma: "Hidden GM-only stat from -10 to +10.",
  situationalDice: "Adds or subtracts dice from skill and attack rolls after action, race, and illumination modifiers.",
  situationalDefense: "Adds or subtracts from Parry and Evade after action, cover, and illumination modifiers.",
  damageModifier: "Adds or subtracts dice from the next damage roll.",
  extraWounds: "Adds fixed wounds after a successful damage calculation.",
  openDamage: "Open damage counts every success, rather than only the kept die result.",
  controlledStrike: "Marks the attack as controlled; weapon damage applies the controlled strike wound reduction.",
  systemRules: "These are world-level system settings configured by the GM in Foundry settings.",
  optionalRaceApproved: "Marks the selected non-human race as approved for creation checks.",
  scholarOption: "Uses the scholar-style Knowledge budget during creation checks.",
  kithiriSocialPenalty: "Applies the Kithiri -1d10 penalty to Command, Deception, and Persuade against non-Kithiri targets.",
  ironHeroes: "Uses the Iron Heroes Health formula: Qi x 3 + 3.",
  bonusSkillPoints: "Manual extra skill points added to creation budget checks.",
  applyCreationDefaults: "Applies starting Qi, money, and race-granted ranks where this system can automate them.",
  postCreationSummary: "Posts the current creation checks and race/primary group summary to chat.",
  newFlaw: "Create an embedded Flaw item. Drag/drop flaw items onto the sheet to add them too.",
  newSkill: "Create an embedded Skill item in this group. Drag/drop Skills items onto the sheet to add them too.",
  newGear: "Create an embedded Equipment item.",
  newTechnique: "Create an embedded Kung Fu Technique item.",
  newCombatPerk: "Create an embedded Combat Perk item.",
  equipmentDrop: "Drop weapon, armor, and equipment items here. Right-click an item to edit or delete it.",
  editItem: "Open this embedded item for editing.",
  deleteItem: "Remove this embedded item from the actor.",
  rollTurnOrder: "Roll Speed for turn order, including race and situational dice modifiers.",
  falling: "Roll falling damage for the listed distance.",
  fire: "Roll fire damage for the selected fire size.",
  suffocation: "Roll Endurance for the listed suffocation or drowning round.",
  objectDamage: "Roll damage against an object's TN and composition.",
  weaponAttack: "Roll this weapon's attack skill against its target defense.",
  weaponDamage: "Roll this weapon's damage dice against the current Damage TN."
};

const MONEY_LABELS = {
  taels: "Taels",
  imperials: "Imperials",
  spades: "Spades",
  liangs: "Liangs",
  paperCurrency: "Paper Currency"
};

function signed(value, suffix = "") {
  const number = Number(value ?? 0);
  if (!number) return "0";
  return `${number > 0 ? "+" : ""}${number}${suffix}`;
}

function getExpertiseEntries(entry) {
  const entries = Array.from(entry?.expertiseList ?? [])
    .map((expertise) => ({
      name: String(expertise?.name ?? "").trim(),
      note: String(expertise?.note ?? "").trim()
    }))
    .filter((expertise) => expertise.name);
  const legacyName = String(entry?.expertise ?? "").trim();
  if (legacyName && !entries.some((expertise) => expertise.name === legacyName)) {
    entries.unshift({
      name: legacyName,
      note: String(entry?.expertiseNote ?? "").trim()
    });
  }
  return entries;
}

function stripHtml(value = "") {
  const div = document.createElement("div");
  div.innerHTML = String(value ?? "");
  return div.textContent?.trim() ?? "";
}

function normalizeKey(value = "") {
  return String(value).trim().toLowerCase().replace(/[^a-z0-9]/g, "");
}

function getSkillIdentity(itemData) {
  const system = itemData?.system ?? {};
  return `${system.group ?? ""}:${normalizeKey(system.skillKey || itemData?.name || "")}`;
}

export class OgreGateActorSheet extends HandlebarsApplicationMixin(ActorSheetV2) {
  static DEFAULT_OPTIONS = {
    ...super.DEFAULT_OPTIONS,
    classes: ["ogre-gate", "actor-sheet"],
    position: {
      width: 980,
      height: 820
    },
    window: {
      ...super.DEFAULT_OPTIONS.window,
      resizable: true
    },
    form: {
      ...super.DEFAULT_OPTIONS.form,
      submitOnChange: true,
      closeOnSubmit: false
    }
  };

  static PARTS = {
    form: {
      template: "systems/ogregatefoundry/templates/actor/actor-sheet.hbs"
    }
  };

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const actor = this.actor;
    const creation = prepareCharacterCreation(actor);
    return {
      ...context,
      actor,
      system: actor.system,
      config: OGRE_GATE,
      help: ACTOR_HELP,
      isGM: game.user.isGM,
      familyRows: this.#prepareFamilyRows(actor),
      moneyRows: this.#prepareMoneyRows(actor),
      creation,
      defenseBudget: creation.groupRows.find((row) => row.key === "defenses"),
      systemRules: {
        deepPenalties: game.settings.get(OGRE_GATE.id, "deepPenalties"),
        deadlyTens: game.settings.get(OGRE_GATE.id, "deadlyTens")
      },
      skillGroups: this.#prepareSkillGroups(actor, creation),
      defenses: this.#prepareDefenses(actor),
      combatActions: this.#prepareCombatActions(),
      attackModes: this.#prepareAttackModes(),
      selectedAttackMode: this.#prepareSelectedAttackMode(actor),
      coverOptions: this.#prepareCoverOptions(),
      illuminationOptions: this.#prepareIlluminationOptions(),
      afflictionTypes: this.#prepareAfflictionTypes(),
      afflictionIntervals: this.#prepareAfflictionIntervals(),
      activeDrains: this.#prepareActiveDrains(actor),
      fireOptions: this.#prepareFireOptions(),
      objectTnOptions: this.#prepareObjectTnOptions(),
      raceOptions: this.#prepareRaceOptions(),
      techniques: actor.items.filter((item) => item.type === "technique"),
      combatTechniques: actor.items.filter((item) => item.type === "combatTechnique"),
      flaws: actor.items.filter((item) => item.type === "flaw"),
      equipment: actor.items.filter((item) => ["weapon", "armor", "equipment"].includes(item.type))
    };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    this._ogreGateListeners?.abort();
    this._ogreGateListeners = new AbortController();
    const listenerOptions = { signal: this._ogreGateListeners.signal };
    this.element.querySelectorAll("input[name], select[name], textarea[name]").forEach((input) => {
      if (!this.#isActorField(input.name)) return;
      input.addEventListener("change", (event) => this.#onFieldChange(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-item-field]").forEach((input) => {
      input.addEventListener("change", (event) => this.#onItemFieldChange(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='roll-skill']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRollSkill(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='roll-defense']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRollDefense(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='roll-turn-order']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRollTurnOrder(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='roll-weapon-attack']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRollWeaponAttack(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='roll-weapon-damage']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRollWeaponDamage(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='roll-falling-damage']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRollFallingDamage(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='roll-fire-damage']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRollFireDamage(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='roll-suffocation']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRollSuffocation(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='roll-object-damage']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRollObjectDamage(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='arm-prepared-strike']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onArmPreparedStrike(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='clear-prepared-strike']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onClearPreparedStrike(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='validate-charge']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onValidateCharge(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='treat-affliction']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onTreatAffliction(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='heal-wounds']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onHealWounds(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='natural-healing']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onNaturalHealing(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='stabilize-dying']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onStabilizeDying(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='apply-drain']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onApplyDrain(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='recover-drain']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onRecoverDrain(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='apply-creation-defaults']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onApplyCreationDefaults(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='post-creation-summary']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onPostCreationSummary(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='create-item']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onCreateItem(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='open-item']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onOpenItem(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='delete-item']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onDeleteItem(event), listenerOptions);
    });
    this.element.querySelectorAll("[data-action='edit-expertise']").forEach((button) => {
      button.addEventListener("click", (event) => this.#onEditExpertise(event), listenerOptions);
    });
    this.element.querySelectorAll(".item-line[data-item-id], .combat-perk-row[data-item-id]").forEach((row) => {
      row.addEventListener("contextmenu", (event) => this.#onItemContextMenu(event), listenerOptions);
    });
    this.element.addEventListener("dragover", (event) => event.preventDefault(), listenerOptions);
    this.element.addEventListener("drop", (event) => this.#onDropItem(event), listenerOptions);
    this.element.querySelectorAll("[data-action='tab']").forEach((tab) => {
      tab.addEventListener("click", (event) => this.#onChangeTab(event), listenerOptions);
    });
    this.#activateTab(this._activeTab ?? "front", "primary");
  }

  #prepareDefenses(actor) {
    return Object.entries(OGRE_GATE.defenses).map(([key, definition]) => {
      const data = actor.system.defenses[key];
      const armorBonus = actor.getArmorDefenseBonus(key);
      const rating = Math.clamp(Number(data.rating ?? 0) + armorBonus, 0, 10);
      return {
        key,
        ...definition,
        shortLabel: this.#shortSkillLabel(definition.label),
        tooltip: this.#defenseTooltip(definition, data, armorBonus, rating),
        rating,
        armorBonus,
        data
      };
    });
  }

  #prepareSkillGroups(actor, creation) {
    const budgetRows = Object.fromEntries((creation?.groupRows ?? []).map((row) => [row.key, row]));
    return Object.entries(OGRE_GATE.skillGroups).filter(([groupKey]) => groupKey !== "defenses").map(([groupKey, group]) => ({
      key: groupKey,
      label: group.label,
      budget: budgetRows[groupKey],
      skills: Array.from(new Map(actor.items
        .filter((item) => item.type === "skills" && item.system.group === groupKey)
        .map((item) => [getSkillIdentity(item.toObject()), item])).values()).map((item) => {
        const skill = item.system;
        const expertiseEntries = getExpertiseEntries(skill).map((expertise) => ({
          ...expertise,
          toggleKey: item.id
        }));
        const description = stripHtml(skill.description);
        return {
          item,
          key: item.id,
          label: item.name,
          displayLabel: item.name,
          shortLabel: this.#shortSkillLabel(item.name),
          tooltip: this.#skillTooltip(item, description),
          expertiseEntries,
          hasExpertise: expertiseEntries.length > 0,
          data: skill
        };
      })
    }));
  }

  #prepareCombatActions() {
    return Object.entries(OGRE_GATE.combatActions).map(([key, action]) => ({
      key,
      ...action,
      tooltip: `Action: ${action.label}. Skill dice ${action.skill === null ? "not allowed" : signed(action.skill, "d10")}; defense ${signed(action.defense)}; movement ${action.moves}.`
    }));
  }

  #prepareAttackModes() {
    return Object.entries(OGRE_GATE.attackModes).map(([key, mode]) => ({
      key,
      ...mode,
      tooltip: [
        `Attack mode: ${mode.label}.`,
        `Attack ${signed(mode.attack, "d10")}; damage ${signed(mode.damage, "d10")}; fixed wounds ${signed(mode.extraWounds)}.`,
        mode.openDamage ? "Uses open damage." : "Uses closed damage unless another rule opens it.",
        mode.nonLethal ? "Non-lethal." : "",
        mode.damageDefense ? `Damage TN can use ${OGRE_GATE.defenses[mode.damageDefense]?.label ?? mode.damageDefense}.` : "",
        mode.workflow ?? ""
      ].filter(Boolean).join(" ")
    }));
  }

  #prepareSelectedAttackMode(actor) {
    const mode = OGRE_GATE.attackModes[actor.system.combat.attackMode] ?? OGRE_GATE.attackModes.normal;
    return {
      ...mode,
      workflow: mode.workflow ?? "No special workflow reminder for this attack mode."
    };
  }

  #prepareAfflictionTypes() {
    return Object.entries(OGRE_GATE.afflictionTypes).map(([key, label]) => ({ key, label }));
  }

  #prepareAfflictionIntervals() {
    return Object.entries(OGRE_GATE.afflictionIntervals).map(([key, label]) => ({ key, label }));
  }

  #prepareActiveDrains(actor) {
    const drains = [];
    if (actor.system.qi.temporary) {
      drains.push({
        label: "Qi",
        amount: actor.system.qi.temporary,
        note: actor.system.status.effectiveQi <= 0 ? "No Kung Fu Techniques while Qi is 0." : `Effective Qi ${actor.system.status.effectiveQi}`
      });
    }
    for (const [key, defense] of Object.entries(actor.system.defenses ?? {})) {
      if (!defense.drain) continue;
      const note = key === "hardiness" && defense.rating <= 0
        ? "At 0 Hardiness, roll Endurance TN 7 every hour or die."
        : key === "wits" && defense.rating <= 0
          ? "At 0 Wits, roll Reasoning TN 7 to communicate or act."
          : key === "resolve" && defense.rating <= 0
            ? "At 0 Resolve, the character responds positively to requests."
            : `Rating ${defense.rating}`;
      drains.push({ label: defense.label, amount: defense.drain, note });
    }
    for (const [groupKey, group] of Object.entries(actor.system.skills ?? {})) {
      for (const [skillKey, skill] of Object.entries(group)) {
        if (!skill.drain) continue;
        drains.push({
          label: skill.label || OGRE_GATE.skillGroups[groupKey]?.skills?.[skillKey] || skillKey,
          amount: skill.drain,
          note: `${OGRE_GATE.skillGroups[groupKey]?.label ?? groupKey} skill`
        });
      }
    }
    for (const item of actor.items.filter((candidate) => candidate.type === "skills" && candidate.system.drain)) {
      drains.push({
        label: item.name,
        amount: item.system.drain,
        note: `${OGRE_GATE.skillGroups[item.system.group]?.label ?? item.system.group} skill`
      });
    }
    return drains;
  }

  #prepareCoverOptions() {
    return Object.entries(OGRE_GATE.cover).map(([key, cover]) => ({
      key,
      ...cover,
      tooltip: `Cover: ${cover.label}. Evade ${signed(cover.evade)}; Parry ${signed(cover.parry)}.`
    }));
  }

  #prepareIlluminationOptions() {
    return Object.entries(OGRE_GATE.illumination).map(([key, illumination]) => ({
      key,
      ...illumination,
      tooltip: `Illumination: ${illumination.label}. Skill dice ${signed(illumination.dice, "d10")}; defense ${signed(illumination.defense)}; Stealth ${signed(illumination.stealth)}.`
    }));
  }

  #prepareFireOptions() {
    return Object.entries(OGRE_GATE.fireDamage).map(([key, fire]) => ({
      key,
      ...fire,
      tooltip: `${fire.label}: ${fire.dice}d10 fire damage.`
    }));
  }

  #prepareObjectTnOptions() {
    return Object.entries(OGRE_GATE.objectTns).map(([tn, object]) => ({
      tn,
      ...object,
      tooltip: `Object TN ${tn}: ${object.composition}; Hardiness ${object.hardiness}; Integrity ${object.integrity}; Evade ${object.evade}.`
    }));
  }

  #prepareRaceOptions() {
    return Object.entries(OGRE_GATE.races).map(([key, label]) => {
      const rule = OGRE_GATE.raceRules[key] ?? {};
      return {
        key,
        label,
        tooltip: `${label}. Advantages: ${rule.advantages ?? "None"}. Penalties: ${rule.penalties ?? "None"}. Gift: ${rule.gift ?? "None"}.`
      };
    });
  }

  #prepareFamilyRows(actor) {
    const labels = {
      siblings: "Siblings",
      birthOrder: "Birth Order",
      mother: "Mother",
      father: "Father",
      sisters: "Sisters",
      brothers: "Brothers",
      swornFamily: "Sworn Family",
      others: "Others"
    };
    return Object.entries(labels).map(([key, label]) => ({
      key,
      label,
      value: actor.system.family[key] ?? ""
    }));
  }

  #prepareMoneyRows(actor) {
    return Object.entries(MONEY_LABELS).map(([key, label]) => ({
      key,
      label,
      value: actor.system.money[key] ?? "",
      type: key === "paperCurrency" ? "text" : "number"
    }));
  }

  #defenseTooltip(definition, defense, armorBonus = 0, rating = defense.rating) {
    return [
      `Roll ${definition.label}: ranks ${defense.ranks} + modifier ${signed(defense.modifier, "d10")}.`,
      `Rating is Base ${defense.base} + Rank ${defense.ranks} + Qi ${defense.qiBonus} + Mod ${signed(defense.modifier)}${defense.drain ? ` - Drain ${defense.drain}` : ""}${armorBonus ? ` + Armor/Shield ${armorBonus}` : ""} = ${rating}.`,
      definition.relevant?.length ? `Relevant against: ${definition.relevant.join(", ")}.` : ""
    ].filter(Boolean).join(" ");
  }

  #skillTooltip(item, description = "") {
    return description || `${item.name}: No skill description entered yet.`;
  }

  #shortSkillLabel(label) {
    const words = String(label ?? "").split(/[ /-]+/).filter(Boolean);
    if (words.length > 1) return words.map((word) => word[0]).join("").slice(0, 3).toUpperCase();
    return String(label ?? "").slice(0, 3).toUpperCase();
  }

  #isActorField(name) {
    return name === "name" || name.startsWith("system.");
  }

  #getActorFieldUpdates() {
    const updates = {};
    this.element.querySelectorAll("input[name], select[name], textarea[name]").forEach((input) => {
      if (input.disabled || !this.#isActorField(input.name)) return;
      updates[input.name] = getInputValue(input);
    });
    return updates;
  }

  async #submitActorFields() {
    const updates = this.#getActorFieldUpdates();
    if (!Object.keys(updates).length) return {};
    await this.actor.update(updates);
    return updates;
  }

  #onFieldChange(event) {
    const input = event.currentTarget;
    return this.actor.update({ [input.name]: getInputValue(input) });
  }

  async #onItemFieldChange(event) {
    const input = event.currentTarget;
    const item = this.actor.items.get(input.dataset.itemId);
    if (!item) return null;
    return item.update({ [input.dataset.itemField]: getInputValue(input) });
  }

  async #promptTargetNumber(label, initial = 6) {
    return new Promise((resolve) => {
      new Dialog({
        title: `${label} TN`,
        content: `
          <form class="ogre-gate-dialog">
            <label>Target Number
              <input type="number" name="tn" value="${Math.clamp(Number(initial ?? 6), 1, 10)}" min="1" max="10" autofocus />
            </label>
          </form>
        `,
        buttons: {
          roll: {
            label: "Roll",
            callback: (html) => {
              const root = html instanceof HTMLElement ? html : html?.[0];
              const value = Number(root?.querySelector("[name='tn']")?.value ?? initial);
              resolve(Math.clamp(value, 1, 10));
            }
          },
          cancel: {
            label: "Cancel",
            callback: () => resolve(null)
          }
        },
        default: "roll",
        close: () => resolve(null)
      }).render(true);
    });
  }

  #getNumberInput(name, initial = 0, { min = -Infinity, max = Infinity } = {}) {
    const value = Number(this.element.querySelector(`[name='${name}']`)?.value ?? initial);
    return Math.clamp(value, min, max);
  }

  #getRollModifier() {
    const action = OGRE_GATE.combatActions[this.actor.system.combat.action] ?? OGRE_GATE.combatActions.skillAndMove;
    return Number(this.actor.system.combat.situationalDice ?? 0) + Number(action.skill ?? 0);
  }

  #useExpertise() {
    return Boolean(this.element.querySelector("[name='roll-expertise']")?.checked);
  }

  async #onRollSkill(event) {
    event.preventDefault();
    await this.#submitActorFields();
    const button = event.currentTarget;
    const item = this.actor.items.get(button.dataset.itemId);
    if (!item) return null;
    const selectedExpertise = Array.from(this.element.querySelectorAll(`[data-expertise-toggle='${item.id}']:checked`))
      .map((input) => input.dataset.expertiseName)
      .filter(Boolean);
    const useExpertise = selectedExpertise.length > 0;
    const label = button.dataset.label || item.name;
    const tn = await this.#promptTargetNumber(label, 6);
    if (!tn) return null;
    return this.actor.rollSkillItem(item, {
      tn,
      modifier: this.#getRollModifier() + (useExpertise ? 1 : 0),
      label: useExpertise ? `${label} (${selectedExpertise.join(", ")})` : label
    });
  }

  async #onRollDefense(event) {
    event.preventDefault();
    await this.#submitActorFields();
    const button = event.currentTarget;
    const defense = this.actor.system.defenses?.[button.dataset.defense];
    const useExpertise = this.#useExpertise() && defense?.expertise;
    const tn = await this.#promptTargetNumber(defense?.label ?? "Defense", 6);
    if (!tn) return null;
    return this.actor.rollDefense(button.dataset.defense, {
      tn,
      modifier: useExpertise ? 1 : 0
    });
  }

  async #onRollTurnOrder(event) {
    event.preventDefault();
    await this.#submitActorFields();
    return this.actor.rollTurnOrder({ modifier: this.actor.system.combat.situationalDice });
  }

  async #onRollWeaponAttack(event) {
    event.preventDefault();
    await this.#submitActorFields();
    const item = this.actor.items.get(event.currentTarget.dataset.itemId);
    const tn = await this.#promptTargetNumber(item?.name ?? "Weapon Attack", 6);
    if (!tn) return null;
    return this.actor.rollAttackWithWeapon(event.currentTarget.dataset.itemId, {
      tn
    });
  }

  async #onRollWeaponDamage(event) {
    event.preventDefault();
    await this.#submitActorFields();
    const item = this.actor.items.get(event.currentTarget.dataset.itemId);
    const hardiness = await this.#promptTargetNumber(`${item?.name ?? "Weapon"} Damage TN`, this.actor.system.defenses.hardiness.rating);
    if (!hardiness) return null;
    return this.actor.rollWeaponDamage(event.currentTarget.dataset.itemId, {
      hardiness,
      open: Boolean(this.element.querySelector("[name='damage-open']")?.checked),
      modifier: Number(this.element.querySelector("[name='damage-modifier']")?.value ?? 0),
      damageBonus: Number(this.actor.system.combat.pendingDamageBonus ?? 0),
      consumeDamageBonus: true,
      extraWounds: Number(this.element.querySelector("[name='extra-wounds']")?.value ?? 0)
    });
  }

  async #onRollFallingDamage(event) {
    event.preventDefault();
    const hardiness = await this.#promptTargetNumber("Falling Damage TN", this.actor.system.defenses.hardiness.rating);
    if (!hardiness) return null;
    return this.actor.rollFallingDamage(this.#getNumberInput("fall-distance", 10, { min: 1, max: 1000 }), {
      hardiness
    });
  }

  async #onRollFireDamage(event) {
    event.preventDefault();
    const hardiness = await this.#promptTargetNumber("Fire Damage TN", this.actor.system.defenses.hardiness.rating);
    if (!hardiness) return null;
    return this.actor.rollFireDamage(this.element.querySelector("[name='fire-size']")?.value ?? "torch", {
      hardiness
    });
  }

  #onRollSuffocation(event) {
    event.preventDefault();
    return this.actor.rollSuffocation(this.#getNumberInput("suffocation-rounds", 0, { min: 0, max: 20 }));
  }

  #onRollObjectDamage(event) {
    event.preventDefault();
    return this.actor.rollObjectDamage({
      dice: this.#getNumberInput("object-damage-dice", 1, { min: 0, max: 12 }),
      objectTn: this.#getNumberInput("object-tn", 5, { min: 1, max: 10 }),
      open: Boolean(this.element.querySelector("[name='object-open']")?.checked)
    });
  }

  async #onArmPreparedStrike(event) {
    event.preventDefault();
    await this.#submitActorFields();
    return this.actor.armPreparedStrike();
  }

  async #onClearPreparedStrike(event) {
    event.preventDefault();
    await this.#submitActorFields();
    await this.actor.clearPreparedStrike();
    ui.notifications.info(`${this.actor.name}'s prepared strike is cleared.`);
  }

  async #onValidateCharge(event) {
    event.preventDefault();
    await this.#submitActorFields();
    return this.actor.postChargeValidation();
  }

  async #onTreatAffliction(event) {
    event.preventDefault();
    await this.#submitActorFields();
    return this.actor.rollAfflictionTreatment();
  }

  async #onHealWounds(event) {
    event.preventDefault();
    await this.#submitActorFields();
    return this.actor.healWounds(this.actor.system.combat.healingAmount);
  }

  async #onNaturalHealing(event) {
    event.preventDefault();
    await this.#submitActorFields();
    return this.actor.applyNaturalHealing();
  }

  async #onStabilizeDying(event) {
    event.preventDefault();
    await this.#submitActorFields();
    return this.actor.stabilizeDying(event.currentTarget.dataset.method);
  }

  async #onApplyDrain(event) {
    event.preventDefault();
    await this.#submitActorFields();
    return new Promise((resolve) => {
      new Dialog({
        title: "Apply Drain",
        content: `
          <form class="ogre-gate-dialog">
            <label>Type
              <select name="type">
                <option value="skill">Skill</option>
                <option value="defense">Defense</option>
                <option value="qi">Qi</option>
              </select>
            </label>
            <label>Key or Name
              <input type="text" name="key" placeholder="speed, hardiness, parry, medicine..." />
            </label>
            <label>Amount
              <input type="number" name="amount" value="1" min="1" max="20" />
            </label>
          </form>
        `,
        buttons: {
          apply: {
            label: "Apply",
            callback: async (html) => {
              const root = html instanceof HTMLElement ? html : html?.[0];
              const updates = await this.actor.applyDrain({
                type: root?.querySelector("[name='type']")?.value ?? "skill",
                key: root?.querySelector("[name='key']")?.value ?? "",
                amount: root?.querySelector("[name='amount']")?.value ?? 1
              });
              if (!Object.keys(updates).length) ui.notifications.warn("No matching drain target found.");
              resolve(true);
            }
          },
          cancel: {
            label: "Cancel",
            callback: () => resolve(false)
          }
        },
        default: "apply",
        close: () => resolve(false)
      }).render(true);
    });
  }

  async #onRecoverDrain(event) {
    event.preventDefault();
    await this.#submitActorFields();
    const updates = await this.actor.recoverDrains(1);
    if (Object.keys(updates).length) ui.notifications.info(`Recovered 1 drain point for ${this.actor.name}.`);
    else ui.notifications.info(`${this.actor.name} has no active drains.`);
    return updates;
  }

  async #onApplyCreationDefaults(event) {
    event.preventDefault();
    await this.#submitActorFields();
    const updates = await this.actor.applyCreationDefaults();
    const count = Object.keys(updates).length;
    if (count) ui.notifications.info(`Applied ${count} creation default(s).`);
    else ui.notifications.info("Creation defaults were already satisfied.");
  }

  async #onPostCreationSummary(event) {
    event.preventDefault();
    await this.#submitActorFields();
    return this.actor.postCreationSummary();
  }

  async #onEditExpertise(event) {
    event.preventDefault();
    const button = event.currentTarget;
    const item = this.actor.items.get(button.dataset.itemId);
    if (!item) return null;
    const skill = item.system;
    const expertiseText = getExpertiseEntries(skill)
      .map((entry) => `${entry.name}${entry.note ? ` | ${entry.note}` : ""}`)
      .join("\n");

    return new Promise((resolve) => {
      new Dialog({
        title: `${button.dataset.label ?? item.name} Expertise`,
        content: `
          <form class="ogre-gate-dialog">
            <label>Expertise Entries
              <textarea name="expertiseList" autofocus placeholder="Expertise name | Optional note">${escapeHtml(expertiseText)}</textarea>
            </label>
            <p class="form-note">Enter one Expertise per line. Use a vertical bar to add an optional note.</p>
          </form>
        `,
        buttons: {
          save: {
            label: "Save",
            callback: async (html) => {
              const root = html instanceof HTMLElement ? html : html?.[0];
              const entries = String(root?.querySelector("[name='expertiseList']")?.value ?? "")
                .split(/\r?\n/)
                .map((line) => {
                  const [name, ...noteParts] = line.split("|");
                  return {
                    name: String(name ?? "").trim(),
                    note: noteParts.join("|").trim()
                  };
                })
                .filter((entry) => entry.name);
              const first = entries[0] ?? { name: "", note: "" };
              await item.update({
                "system.expertise": first.name,
                "system.expertiseNote": first.note,
                "system.expertiseList": entries
              });
              resolve(true);
            }
          },
          clear: {
            label: "Clear",
            callback: async () => {
              await item.update({
                "system.expertise": "",
                "system.expertiseNote": "",
                "system.expertiseList": []
              });
              resolve(true);
            }
          },
          cancel: {
            label: "Cancel",
            callback: () => resolve(false)
          }
        },
        default: "save",
        close: () => resolve(false)
      }).render(true);
    });
  }

  async #onCreateItem(event) {
    event.preventDefault();
    event.stopPropagation();
    const type = event.currentTarget.dataset.type;
    if (!type) return;

    const label = type === "skills" ? "Skill" : OGRE_GATE.itemTypes[type] ?? "Item";
    const groupKey = event.currentTarget.dataset.group;
    const baseName = type === "skills" && groupKey
      ? `New ${OGRE_GATE.skillGroups[groupKey]?.label ?? ""} Skill`.trim()
      : `New ${label}`;
    const itemData = {
      name: this.#getUniqueItemName(baseName, type, groupKey),
      type
    };
    if (groupKey) itemData.system = { group: groupKey };
    const [item] = await this.actor.createEmbeddedDocuments("Item", [itemData]);
    item?.sheet?.render(true);
  }

  #getUniqueItemName(baseName, type, groupKey = "") {
    const used = new Set(this.actor.items
      .filter((item) => item.type === type && (!groupKey || item.system?.group === groupKey))
      .map((item) => item.name));
    if (!used.has(baseName)) return baseName;
    for (let index = 2; index < 1000; index += 1) {
      const candidate = `${baseName} ${index}`;
      if (!used.has(candidate)) return candidate;
    }
    return `${baseName} ${Date.now()}`;
  }

  #findExistingSkillItem(itemData) {
    const identity = getSkillIdentity(itemData);
    if (!identity || identity.endsWith(":")) return null;
    return this.actor.items.find((item) => item.type === "skills" && getSkillIdentity(item.toObject()) === identity) ?? null;
  }

  #onOpenItem(event) {
    event.preventDefault();
    const item = this.actor.items.get(event.currentTarget.dataset.itemId);
    return item?.sheet?.render(true);
  }

  async #onDeleteItem(event) {
    event.preventDefault();
    const item = this.actor.items.get(event.currentTarget.dataset.itemId);
    if (!item) return;
    const confirmed = await Dialog.confirm({
      title: `Delete ${item.name}?`,
      content: `<p>Remove <strong>${item.name}</strong> from ${this.actor.name}?</p>`,
      yes: () => true,
      no: () => false,
      defaultYes: false
    });
    if (!confirmed) return;
    return item.delete();
  }

  async #onItemContextMenu(event) {
    event.preventDefault();
    const item = this.actor.items.get(event.currentTarget.dataset.itemId);
    if (!item) return;
    return new Dialog({
      title: item.name,
      content: `<p>Choose an action for <strong>${item.name}</strong>.</p>`,
      buttons: {
        edit: {
          label: "Edit",
          callback: () => item.sheet.render(true)
        },
        delete: {
          label: "Delete",
          callback: async () => {
            const confirmed = await Dialog.confirm({
              title: `Delete ${item.name}?`,
              content: `<p>Remove <strong>${item.name}</strong> from ${this.actor.name}?</p>`,
              yes: () => true,
              no: () => false,
              defaultYes: false
            });
            if (confirmed) await item.delete();
          }
        }
      },
      default: "edit"
    }).render(true);
  }

  async #onDropItem(event) {
    event.preventDefault();
    event.stopPropagation();
    const raw = event.dataTransfer?.getData("text/plain");
    if (!raw) return;

    let data;
    try {
      data = JSON.parse(raw);
    } catch (_error) {
      return;
    }

    if (data.type === "Folder") {
      const folder = await fromUuid(data.uuid);
      if (!folder || folder.type !== "Item") {
        ui.notifications.warn("Only folders of Item documents can be dropped onto an Ogre Gate sheet.");
        return;
      }
      return this.#onDropItemFolder(folder, event.target);
    }

    if (data.type !== "Item") return;

    const item = await Item.implementation.fromDropData(data);
    if (!item) return;

    const skillGroup = event.target?.closest?.("[data-skill-group]")?.dataset?.skillGroup;
    return this.#addDroppedItem(item, skillGroup);
  }

  async #addDroppedItem(item, skillGroup = "") {
    const itemData = item.toObject();
    delete itemData._id;
    if (itemData.type === "skills" && skillGroup) itemData.system = { ...itemData.system, group: skillGroup };
    const existing = itemData.type === "skills" ? this.#findExistingSkillItem(itemData) : null;
    if (existing) {
      ui.notifications.info(`${existing.name} is already on ${this.actor.name}.`);
      return existing.sheet?.render(true);
    }
    await this.actor.createEmbeddedDocuments("Item", [itemData]);
    ui.notifications.info(`Added ${item.name} to ${this.actor.name}.`);
  }

  async #onDropItemFolder(folder, target) {
    const skillGroup = target?.closest?.("[data-skill-group]")?.dataset?.skillGroup ?? "";
    const items = await this.#collectFolderItems(folder);
    const skills = items.filter((item) => item?.type === "skills");
    if (!skills.length) {
      ui.notifications.warn(`${folder.name} does not contain Ogre Gate Skill items.`);
      return;
    }

    const itemData = [];
    const seen = new Set(this.actor.items.filter((item) => item.type === "skills").map((item) => getSkillIdentity(item.toObject())));
    for (const item of skills) {
      const data = item.toObject();
      delete data._id;
      if (skillGroup) data.system = { ...data.system, group: skillGroup };
      const identity = getSkillIdentity(data);
      if (seen.has(identity)) continue;
      seen.add(identity);
      itemData.push(data);
    }

    if (!itemData.length) {
      ui.notifications.info(`All Skills in ${folder.name} are already on ${this.actor.name}.`);
      return;
    }
    await this.actor.createEmbeddedDocuments("Item", itemData);
    ui.notifications.info(`Added ${itemData.length} Skill item(s) from ${folder.name} to ${this.actor.name}.`);
  }

  async #collectFolderItems(folder) {
    const entries = [...(folder.contents ?? [])];
    for (const child of folder.getSubfolders?.() ?? []) {
      entries.push(...await this.#collectFolderItems(child));
    }
    return Promise.all(entries.map(async (entry) => {
      if (entry?.documentName === "Item" && typeof entry.toObject === "function") return entry;
      if (entry?.uuid) return fromUuid(entry.uuid);
      return null;
    }));
  }

  #activateTab(tab, group) {
    this.element.querySelectorAll(`.sheet-tabs [data-group='${group}']`).forEach((link) => {
      link.classList.toggle("active", link.dataset.tab === tab);
    });
    this.element.querySelectorAll(`.sheet-body .tab[data-group='${group}']`).forEach((panel) => {
      panel.classList.toggle("active", panel.dataset.tab === tab);
    });
  }

  #onChangeTab(event) {
    event.preventDefault();
    const tab = event.currentTarget.dataset.tab;
    const group = event.currentTarget.dataset.group;
    this._activeTab = tab;
    this.#activateTab(tab, group);
  }
}
