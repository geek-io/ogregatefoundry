# Ogre Gate Rules Implementation Roadmap

This roadmap tracks book-to-system implementation work. Compendium item descriptions preserve the rules text needed at the table.

## Current Baseline

- Character, NPC, and monster actor data models exist.
- Weapon, armor, equipment, kung fu technique, ritual, and flaw item models exist.
- Character sheet fields cover the official sheet's identity, defenses, skill groups, qi, wounds, imbalance, karma, family, money, equipment, techniques, grudges, experience, and flaws.
- Core Network System rolling exists for ranked d10 pools, 0d10 rolls, total successes, and open/closed damage.

## Current Release Plan

- `v0.2.0`: Live-table stabilization, technique importing, orderable skill lists, and a compact NPC/monster sheet.
- Next: NPC/enemy special abilities, monster sheet refinements, and threat compendium/import polish from actual-play feedback.
- Later: return to rituals, broader Chapter 4 support, and remaining setting/GM tools.

## Next Rules Passes

1. Character creation
   - Done: race/optional race fields, optional race approval warning, Scholar Option, two primary skill groups, skill budgets, optional race cost adjustments, race roll modifiers, Apply Creation Defaults, flaw-point overage checks, sect/sifu and reputation checks, discipline rank checks, starting kung fu count, combat perk count, Qi defense-dot count, starting money check, Iron Heroes wounds option, and formal character creation chat summary.
   - Next: starting equipment picker after the equipment sprint is stable; then Juren extra-arm action workflow, Kithiri Multi-Ego workflow, Ouyan/Hechi gift helpers, and sect-specific starting technique availability.

2. Core rules
   - Done: target number helper, relevant defense display, combat action choices, situational modifiers, cover/prone defense modifiers, illumination, turn order, weapon attack rolls, natural-10 damage-bonus handoff, reach/closing modifiers, attack modes, attack-mode workflow reminders, prepared strike tracker and interrupt-spend handling, charge/mounted validation reminders including mounted follow-through and moving-mount Cathartic Imbalance, maim/disarm outcome checklists, weapon damage rolls, movement derivation, wound states, dying counter, healing, Medicine/Meditation stabilization, Qi Duel resolution and tie buildup, poison/disease Potency exposure, concurrent affliction tracking with stacked penalties, visible progression and lethality tracking, Medicine cadence/treatment outcomes, poison/disease/substance itemization and compendiums, Controlled Strike tracking, Deep Penalties and Deadly 10s world settings, temporary Skill/Defense/Qi drains, chat wound application, object attacks, and falling/fire/suffocation helpers.
   - Next: core Chapter 2 bug fixes from testing, then move to the next version slice.

3. Kung fu techniques
   - Done: item-based activation-skill rolls, normal/Cathartic use choice, Imbalance award rules, Qi Spirit threshold/table tracking, daily possession control, meditation Imbalance recovery, a packaged Chapter 3 Kung Fu Technique compendium with structured technique item fields, compendium text cleanup, Purge Spirit possession automation, Purge Affliction mental-affliction automation, active Stance tracking with Cathartic maintenance, generic Counter reaction guardrails, formation stance participant/reminder details, structured combination Technique prerequisites, Requirement badges for non-automated prerequisites, structured required Flaw and Skill-rank checks for clear actor-known requirements, Cathartic-only Open Damage handling, fixed Extra Wound damage-card modifiers, direct-Wound technique outcomes, target-locked technique drain application buttons, Target Effect reminders for common state outcomes, technique consequence/user-cost reminders, Qi-rank technique folders, roll target/modifier fields, Secret/lost/manual access badges, Martial Discipline rank enforcement, and Profound/Evil/Immortal Cathartic-only enforcement.
   - Next: additional individual Technique effects, general non-technique requirement automation where safe, and fuller mastery-source workflow.

4. Equipment
   - Current v0.1.7 focus: weapon and armor compendiums, equipment categories, item cost/currency display, gear drag/drop cleanup, carried/equipped usability, and weapon/armor rule polish for table use.
   - Next: mounts, transport, goods, alchemical gear beyond existing substances, and starting equipment picker integration.

5. NPCs, threats, and monsters
   - Current v0.1.8 target: NPC tracker sheet refinement, enemy/monster sheet layout styled from the book, quick combat stat blocks, and threat/monster compendiums with special abilities and roll buttons.

6. Rituals and special substances
   - Ritual compendium and activation handling.
   - Done: Poison, disease, herbal cure, longevity, and transformative substance compendiums with item-specific descriptions, a shared Chapter 2 poison/disease rules reference journal, concurrent poison/disease treatment loading, stacked affliction penalties, Potency exposure and manual progression/death-clock controls, applicable remedy/herbal cure effects, Purple Spirit Qi blocking/purge cleanup, special thorn/wine onset effects, Malignant Wind failed-treatment wounds, stored dose consumption, manual effect expiration, resource-changing herbal/longevity uses, Life Prolonging Pill course/lifespan tracking, and duration-based non-affliction effect tracking.
   - Next: calendar-driven automatic expiration and broader ritual activation handling after v0.1.8.

7. Martial world and setting support
   - Sect/judgeable reputation tracking.
   - Journal/compendium content indexes for sects, places, institutions, and objects of power where licensing permits.

8. GM tools
   - Encounter/travel helpers.
   - Grudge and fate trackers.
   - Optional campaign timeline and NPC growth tools.
